import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'app-customer-view',
  templateUrl: './customer-view.component.html',
  styleUrls: ['./customer-view.component.css']
})
export class CustomerViewComponent implements OnInit {
  customers: any;
  constructor(private http: Http) { 

  }

  ngOnInit() {
    this.http.get('http://localhost:8080/customers')
    .subscribe(response =>{
        this.customers = response.json();
    });
  }

}
