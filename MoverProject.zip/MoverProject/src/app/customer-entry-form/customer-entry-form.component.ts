import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Http, Headers, Request, RequestMethod, Response} from '@angular/http';

@Component({
  selector: 'app-customer-entry-form',
  templateUrl: './customer-entry-form.component.html',
  styleUrls: ['./customer-entry-form.component.css'],

})
export class CustomerEntryFormComponent  {
  customertitle: string;
  customerForm: FormGroup;
  postStatus: any;


  constructor(private http: Http, private _fb: FormBuilder){
    this.customertitle = "Enter the customer detail"
    this.customerForm = this._fb.group({
     // customer_id: 0,
     firsName: ['', [Validators.required,
                  Validators.minLength(3),
                  Validators.maxLength(30)]],
      lastName: ['', [Validators.required,
                    Validators.minLength(3),
                    Validators.maxLength(30)]],
      phone: ['', [Validators.required,
        Validators.minLength(3),
        Validators.maxLength(30)]],
      email: ['', [Validators.required]],
      address: ['', [Validators.required]],
      city: ['', [Validators.required]]
    })
  }

create(){
  console.log(this.postStatus );
  this.http.post('http://localhost:8080/customer',JSON.stringify(this.customerForm.value))
  .subscribe(response =>{
    this.postStatus = response.json();
   
  });
}
}
