import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-entry-form',
  templateUrl: './bill-entry-form.component.html',
  styleUrls: ['./bill-entry-form.component.css']
})
export class BillEntryFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
